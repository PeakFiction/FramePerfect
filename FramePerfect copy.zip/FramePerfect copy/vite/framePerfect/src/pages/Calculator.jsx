export default function Calculator() {
  return (
    <div className="page">
      <h1>Calculator</h1>
      <p>Port inputs and formulas from your Electron calculatorWindow.html here.</p>
    </div>
  );
}
