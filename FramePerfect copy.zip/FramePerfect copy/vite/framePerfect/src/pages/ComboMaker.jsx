import { useExportData, usePrefs, useCharacter } from '../data/useData.js';
import { useSearchParams } from 'react-router-dom';
import { useMemo } from 'react';

export default function ComboMaker() {
  const data = useExportData();
  const { isFavorite, toggleFavorite, getNote, setNote } = usePrefs();
  const [params] = useSearchParams();
  const charName = params.get('char') || '';

  const character = useCharacter(data, charName);
  const moves = useMemo(() => {
    if (!data || !character) return [];
    const cid = character.characterID ?? character.id ?? character._id;
    return (data.moves || []).filter(m => (m.characterID ?? m.character_id ?? m.charId) === cid);
  }, [data, character]);

  return (
    <div className="page">
      <h1>{charName || 'Moves'}</h1>
      <ul className="list">
        {moves.map((m) => {
          const id = m.moveID ?? m.id ?? m._id;
          const label = m.notation || m.name || m.command || `Move ${id}`;
          const props = m.properties || m.tags || '';
          return (
            <li key={id} className="item">
              <div className="row">
                <div className="col">
                  <div className="title">{label}</div>
                  <div className="meta">{props}</div>
                </div>
                <button className="fav" onClick={() => toggleFavorite(id)}>
                  {isFavorite(id) ? '★' : '☆'}
                </button>
              </div>
              <textarea
                placeholder="Add note…"
                defaultValue={getNote(id)}
                onBlur={(e) => setNote(id, e.target.value)}
              />
            </li>
          );
        })}
      </ul>
    </div>
  );
}
